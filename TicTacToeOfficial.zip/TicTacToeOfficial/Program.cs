﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
///////////////////////////////////////////////////////
// This game works with windows.net framework and forms
// this program allows a computer to play agaisnt a user in simple game of tic tac toe
// this program allows the user to either beat the computer, lose, or draw
// this program allows you start a game, start a new game, and also exit
namespace TicTacToeG
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
