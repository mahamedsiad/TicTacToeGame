﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TicTacToeG
{
    public partial class Form1 : Form
    {
        short movem = 0;
        public enum player
        {
            //enum for letters
            X, O
        }
        //initiallize player
        player currentplayer;
        //new random number
        Random random = new Random();
        //initialize List
        List<Button> buttons;
        public Form1()
        {
            InitializeComponent();
            //function to restart game
            restartgame();
        }


        private void TicTacToe(object sender, EventArgs e)
        {
            disableButtons();
        }

        private void disableButtons()
        {
            //this disables the buttons
            Enabledisablebutton(false);
        }
        //resets the game
        private void resetGame(object sender, EventArgs e)
        {
            
            Enabledisablebutton(true);

        }

        private void Enabledisablebutton(bool value)
        {
            //set buttons value to true or false
            button1.Enabled = value;
            button2.Enabled = value;
            button3.Enabled = value;
            button4.Enabled = value;
            button5.Enabled = value;
            button6.Enabled = value;
            button7.Enabled = value;
            button8.Enabled = value;
            button9.Enabled = value;
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button11_Click(object sender, EventArgs e)
        {
            //exit application
            Application.Exit();
        }

        private void button12_Click(object sender, EventArgs e)
        {

            Enabledisablebutton(false);
            restartgame();
            label1.Text = "??";
            //disable button
            Enabledisablebutton(false);
            //restarts game
            restartgame();
        }

        private void cpmove(object sender, EventArgs e)
        {
            //if number of buttons are greater than 0 run code
            if (buttons.Count > 0)
            {
                //changers current player
                int index = random.Next(buttons.Count);
                buttons[index].Enabled = false;
                currentplayer = player.O;
                buttons[index].Text = currentplayer.ToString();
                buttons[index].BackColor = Color.AliceBlue;
                buttons.RemoveAt(index);
                check();
                cptimer.Stop();
            }
        }

        private void playerclickb(object sender, EventArgs e)
        {
            //set button to button object, set player/text, check for winner

            var button = (Button)sender;
            currentplayer = player.X;
            button.Text = currentplayer.ToString();
            button.Enabled = false;
            button.BackColor = Color.Green;
            buttons.Remove(button);
            check();
            cptimer.Start();
        }

        private void check()
        {
            //checks for the winner
            if (button1.Text == "X" && button2.Text == "X" && button3.Text == "X" ||
            button4.Text == "X" && button5.Text == "X" && button6.Text == "X" ||
            button7.Text == "X" && button8.Text == "X" && button9.Text == "X" ||
            button1.Text == "X" && button4.Text == "X" && button7.Text == "X" ||
            button2.Text == "X" && button5.Text == "X" && button8.Text == "X" ||
            button3.Text == "X" && button6.Text == "X" && button9.Text == "X" ||
            button1.Text == "X" && button5.Text == "X" && button9.Text == "X" ||
            button3.Text == "X" && button5.Text == "X" && button7.Text == "X"
                )
            {
                //displays winner and restarts thegame
                label1.Text = "Player Wins";
                restartgame();
                restartgame();
            }

            else if (
                //checks for computer winner
            button1.Text == "O" && button2.Text == "O" && button3.Text == "O" ||
            button4.Text == "O" && button5.Text == "O" && button6.Text == "O" ||
            button7.Text == "O" && button8.Text == "O" && button9.Text == "O" ||
            button1.Text == "O" && button4.Text == "O" && button7.Text == "O" ||
            button2.Text == "O" && button5.Text == "O" && button8.Text == "O" ||
            button3.Text == "O" && button6.Text == "O" && button9.Text == "O" ||
            button1.Text == "O" && button5.Text == "O" && button9.Text == "O" ||
            button3.Text == "O" && button5.Text == "O" && button7.Text == "O"
                )
            {
                //displays computer winner and restarts the game
                label1.Text = "Computer Wins";
                restartgame();
                restartgame();
            }
            //checks for tie or draw
            else if (movem == 8)
            {
                //displays that it's a tie anf restarts game
                label1.Text = "TIE";
                restartgame();
            }
            movem++;



        }

        private void restartgame()
        {
            //changes all the buttons and sets them
            buttons = new List<Button> { button1, button2, button3, button4, button5, button6, button7, button8, button9 };
            foreach (Button x in buttons)
            {
                x.Enabled = true;
                x.Text = "??";
                x.BackColor = DefaultBackColor;
                movem = 0;

            }
        }
    }
}
